import React from 'react';
import {
    Create,
    Delete,
    Edit,
    translate,
    Datagrid,
    DateField,
    DateInput,
    TextField,
    Filter,
    FormTab,
    List,
    LongTextInput,
    TabbedForm,
    EmailField,
    NumberField,
    TextInput,
    SelectInput,
    ReferenceField,
    ReferenceInput,
} from 'admin-on-rest';
import Icon from 'material-ui/svg-icons/social/person';

import EditButton from '../buttons/EditButton';
import FullNameField from './FullNameField';

export const CustomerIcon = Icon;

const CustomerFilter = (props) => (
    <Filter {...props}>
        <TextInput label="Csm" source="csm" alwaysOn />
	<TextInput label="Phone" source="phone" alwaysOn />
	<TextInput label="Level" source="level" alwaysOn />
	<TextInput label="Uname" source="uname" alwaysOn />
	<TextInput label="Email" source="email" alwaysOn />
	<TextInput label="Ma ST" source="MST" alwaysOn />
    </Filter>
);

const colored = WrappedComponent => props => props.record[props.source] > 500 ?
    <span style={{ color: 'red' }}><WrappedComponent {...props} /></span> :
    <WrappedComponent {...props} />;

const ColoredNumberField = colored(NumberField);
ColoredNumberField.defaultProps = NumberField.defaultProps;

export const CustomerList = (props) => (
    <List {...props} filters={<CustomerFilter />} perPage={25}>
        <Datagrid bodyOptions={{ stripedRows: true, showRowHover: true }}>
            <TextField source="uname" />
            <TextField source="cusname" />
            <TextField source="phone" />
            <ReferenceField label="csm" source="csmname" reference="employees">
                <TextField source="name" />
            </ReferenceField>
            <TextField source="address" />
            <DateField source="birthday" type="date" />
            <EmailField source="email" />
            <TextField source="level" />
            <TextField source="MST" />
            <TextField source="total" />
            <EditButton />
        </Datagrid>
    </List>
);

export const CustomerCreate = (props) => (
    <Create title="Add new customer" {...props}>
        <TabbedForm>
            <FormTab label="Customer">
                <TextInput source="uname" style={{ display: 'inline-block', marginLeft: 32 }} />
                <TextInput source="cusname" style={{ display: 'inline-block', marginLeft: 32 }} />
                <TextInput source="phone" style={{ display: 'inline-block', marginLeft: 32 }} />
                <TextInput source="address" style={{ display: 'inline-block', marginLeft: 32 }} />
                <TextInput source="MST" style={{ display: 'inline-block', marginLeft: 32 }} />
		<ReferenceInput label="csm" source="csmname" reference="employees" allowEmpty  style={{ display: 'inline-block', marginLeft: 32}}>
		    <SelectInput optionText="name" source="name"/>
		</ReferenceInput>
                <TextInput source="details" style={{ display: 'inline-block', marginLeft: 32 }} />
                <TextInput source="total" style={{ display: 'inline-block', marginLeft: 32 }} />
                <TextInput source="pwd" style={{ display: 'inline-block', marginLeft: 32 }} />
                <TextInput source="email" style={{ display: 'inline-block', marginLeft: 32 }} />
                <DateInput source="birthday" style={{ display: 'inline-block', marginLeft: 32 }} />
                <DateInput source="regday" style={{ display: 'inline-block', marginLeft: 32 }} />
		<SelectInput source="level" choices={[
                    { id: '1', name: '1' },
                    { id: '2', name: '2' },
                    { id: '3', name: '3' },
                ]} style={{ display: 'inline-block', marginLeft: 32 }} />                
		<SelectInput source="type" choices={[
                    { id: '1', name: '1' },
                    { id: '2', name: '2' },
                    { id: '3', name: '3' },
                ]} style={{ display: 'inline-block', marginLeft: 32 }} />
            </FormTab>
        </TabbedForm>
    </Create>
);

const CustomerTitle = ({ record }) => record ? <FullNameField record={record} size={32} /> : null;

export const CustomerEdit = (props) => (
    <Edit title={<CustomerTitle />} {...props}>
        <TabbedForm>
            <FormTab label="Customers">
                <TextInput source="uname" style={{ display: 'inline-block', marginLeft: 32 }} />
                <TextInput source="cusname" style={{ display: 'inline-block', marginLeft: 32 }} />
                <TextInput source="phone" style={{ display: 'inline-block', marginLeft: 32 }} />
                <TextInput source="address" style={{ display: 'inline-block', marginLeft: 32 }} />
                <TextInput source="MST" style={{ display: 'inline-block', marginLeft: 32 }} />
		<ReferenceInput label="csm" source="csmname" reference="employees" allowEmpty  style={{ display: 'inline-block', marginLeft: 32}}>
		    <SelectInput source="name"/>
		</ReferenceInput>
                <TextInput source="details" style={{ display: 'inline-block', marginLeft: 32 }} />
                <TextInput source="total" style={{ display: 'inline-block', marginLeft: 32 }} />
                <TextInput source="pwd" style={{ display: 'inline-block', marginLeft: 32 }} />
                <TextInput source="email" style={{ display: 'inline-block', marginLeft: 32 }} />
                <DateInput source="birthday" style={{ display: 'inline-block', marginLeft: 32 }} />
                <DateInput source="regday" style={{ display: 'inline-block', marginLeft: 32 }} />
		<SelectInput source="level" choices={[
                    { id: '1', name: '1' },
                    { id: '2', name: '2' },
                    { id: '3', name: '3' },
                ]} style={{ display: 'inline-block', marginLeft: 32 }} />                
		<SelectInput source="type" choices={[
                    { id: '1', name: '1' },
                    { id: '2', name: '2' },
                    { id: '3', name: '3' },
                ]} style={{ display: 'inline-block', marginLeft: 32 }} />
            </FormTab>
        </TabbedForm>
    </Edit>
);

const CustomerDeleteTitle = translate(({ record, translate }) => <span>
    {translate('Delete')}&nbsp;
    {record && `${record.name}`}
</span>);

export const CustomerDelete = (props) => <Delete {...props} title={<CustomerDeleteTitle />} />;
