import React from 'react';
import { ReferenceField } from 'admin-on-rest';

import FullNameField from './FullNameField';

const WareReferenceField = (props) => (
    <ReferenceField source="id" reference="Ware" {...props}>
        <FullNameField />
    </ReferenceField>
);
WareReferenceField.defaultProps = {
    source: 'id',
    addLabel: true,
};

export default WareReferenceField;
