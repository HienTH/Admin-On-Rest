import React from 'react';
import {
    Create,
    Delete,
    Edit,
    translate,
    Datagrid,
    DateField,
    DateInput,
    TextField,
    Filter,
    FormTab,
    ReferenceField,
    SelectField,
    List,
    LongTextInput,
    TabbedForm,
    EmailField,
    NumberField,
    TextInput,
    SelectInput,
    ReferenceInput,
} from 'admin-on-rest';
import Icon from 'material-ui/svg-icons/social/person';

import EditButton from '../buttons/EditButton';
import FullNameField from './FullNameField';

export const WareIcon = Icon;

const WareFilter = (props) => (
    <Filter {...props}>
    </Filter>
);

const colored = WrappedComponent => props => props.record[props.source] > 500 ?
    <span style={{ color: 'red' }}><WrappedComponent {...props} /></span> :
    <WrappedComponent {...props} />;

const ColoredNumberField = colored(NumberField);
ColoredNumberField.defaultProps = NumberField.defaultProps;

export const WareList = (props) => (
    <List {...props} filters={<WareFilter />}>
        <Datagrid bodyOptions={{ stripedRows: true, showRowHover: true }}>
            <TextField source="serial" />
            <TextField source="warename" />
            <TextField source="pricepay" />
            <TextField source="pricebuy" />
	    <ReferenceField label="ordername" source="ordername" reference="orderform">
                <TextField source="name" />
            </ReferenceField>
            <DateField source="date" type="date" />
            <EditButton />
        </Datagrid>
    </List>
);

export const WareCreate = (props) => (
    <Create title="Add new ware" {...props}>
        <TabbedForm>
            <FormTab label="Ware">
                <TextInput source="serial" style={{ display: 'inline-block', marginLeft: 32 }} />
		<TextInput source="warename" style={{ display: 'inline-block', marginLeft: 32 }} />                
		<ReferenceInput label="ordername" source="ordername" reference="orderform" allowEmpty  style={{ display: 'inline-block', marginLeft: 32}}>
		    <SelectInput optionText="name" source="name"/>
		</ReferenceInput>
		<TextInput source="pricebuy" style={{ display: 'inline-block', marginLeft: 32 }} />
		<TextInput source="pricepay" style={{ display: 'inline-block', marginLeft: 32 }} />
		<TextInput source="details" style={{ display: 'inline-block', marginLeft: 32 }} />
		<DateInput source="date" style={{ display: 'inline-block', marginLeft: 32 }} />
                <TextInput source="warehouse" style={{ display: 'inline-block', marginLeft: 32 }} />
                <SelectInput source="status" choices={[
                    { id: 'on', name: 'On' },
                    { id: 'off', name: 'Off' },
                ]} style={{ display: 'inline-block', marginLeft: 32 }}/>
            </FormTab>
        </TabbedForm>
    </Create>
);

const WareTitle = ({ record }) => record ? <FullNameField record={record} size={32} /> : null;

export const WareEdit = (props) => (
    <Edit title={<WareTitle />} {...props}>
        <TabbedForm>
            <FormTab label="Ware">
		                <TextInput source="serial" style={{ display: 'inline-block', marginLeft: 32 }} />
		<TextInput source="warename" style={{ display: 'inline-block', marginLeft: 32 }} />                
		<ReferenceInput label="ordername" source="ordername" reference="orderform" allowEmpty  style={{ display: 'inline-block', marginLeft: 32}}>
		    <SelectInput source="name"/>
		</ReferenceInput>
		<TextInput source="pricebuy" style={{ display: 'inline-block', marginLeft: 32 }} />
		<TextInput source="pricepay" style={{ display: 'inline-block', marginLeft: 32 }} />
		<TextInput source="details" style={{ display: 'inline-block', marginLeft: 32 }} />
		<DateInput source="date" style={{ display: 'inline-block', marginLeft: 32 }} />
                <TextInput source="warehouse" style={{ display: 'inline-block', marginLeft: 32 }} />
                <SelectInput source="status" choices={[
                    { id: 'on', name: 'On' },
                    { id: 'off', name: 'Off' },
                ]} style={{ display: 'inline-block', marginLeft: 32 }}/>
            </FormTab>
        </TabbedForm>
    </Edit>
);

const WareDeleteTitle = translate(({ record, translate }) => <span>
    {translate('Delete')}&nbsp;
    {record && `${record.warename}`}
</span>);

export const WareDelete = (props) => <Delete {...props} title={<WareDeleteTitle />} />;
