import React from 'react';
import { ReferenceField } from 'admin-on-rest';

import FullNameField from './FullNameField';

const OrderformReferenceField = (props) => (
    <ReferenceField source="id" reference="Orderform" {...props}>
        <FullNameField />
    </ReferenceField>
);
OrderformReferenceField.defaultProps = {
    source: 'id',
    addLabel: true,
};

export default OrderformReferenceField;
