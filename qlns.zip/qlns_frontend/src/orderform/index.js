import React from 'react';
import {
    Create,
    Delete,
    Edit,
    translate,
    Datagrid,
    DateField,
    DateInput,
    TextField,
    Filter,
    FormTab,
    List,
    LongTextInput,
    TabbedForm,
    EmailField,
    NumberField,
    TextInput,
    SelectInput,
} from 'admin-on-rest';
import Icon from 'material-ui/svg-icons/social/person';

import EditButton from '../buttons/EditButton';
import FullNameField from './FullNameField';

export const OrderformIcon = Icon;

const OrderformFilter = (props) => (
    <Filter {...props}>
    </Filter>
);

const colored = WrappedComponent => props => props.record[props.source] > 500 ?
    <span style={{ color: 'red' }}><WrappedComponent {...props} /></span> :
    <WrappedComponent {...props} />;

const ColoredNumberField = colored(NumberField);
ColoredNumberField.defaultProps = NumberField.defaultProps;

export const OrderformList = (props) => (
    <List {...props} filters={<OrderformFilter />} sort={{ field: 'last_seen', order: 'DESC' }} perPage={25}>
        <Datagrid bodyOptions={{ stripedRows: true, showRowHover: true }}>
            <TextField source="user" />
	    <TextField source="name" />
	    <DateField source="date" type="date" />
            <TextField source="type" />
            <TextField source="details" />
            <EditButton />
        </Datagrid>
    </List>
);

export const OrderformCreate = (props) => (
    <Create title="Add new orderform" {...props}>
        <TabbedForm>
            <FormTab label="Orderform">
                <TextInput source="user" style={{ display: 'inline-block', marginLeft: 32  }} />
                <TextInput source="name" style={{ display: 'inline-block', marginLeft: 32  }} />
                <DateInput source="date" style={{ display: 'inline-block', marginLeft: 32  }} />
                <SelectInput source="type" choices={[
                    { id: 'admin', name: 'Admin' },
                    { id: 'mod', name: 'Mod' },
                    { id: 'member', name: 'Member' },
                ]} style={{ display: 'inline-block', marginLeft: 32  }}/>
                <TextInput source="details" style={{ display: 'inline-block', marginLeft: 32  }} />
            </FormTab>
        </TabbedForm>
    </Create>
);

const OrderformTitle = ({ record }) => record ? <FullNameField record={record} size={32} /> : null;

export const OrderformEdit = (props) => (
    <Edit title={<OrderformTitle />} {...props}>
        <TabbedForm>
            <FormTab label="Orderform">
                <TextInput source="user" style={{ display: 'inline-block', marginLeft: 32  }} />
                <TextInput source="name" style={{ display: 'inline-block', marginLeft: 32  }} />
                <DateInput source="date" style={{ display: 'inline-block', marginLeft: 32  }} />
                <SelectInput source="type" choices={[
                    { id: 'admin', name: 'Admin' },
                    { id: 'mod', name: 'Mod' },
                    { id: 'member', name: 'Member' },
                ]} style={{ display: 'inline-block', marginLeft: 32  }}/>
		<TextInput source="details" style={{ display: 'inline-block', marginLeft: 32  }} />
            </FormTab>
        </TabbedForm>
    </Edit>
);

const OrderformDeleteTitle = translate(({ record, translate }) => <span>
    {translate('Delete')}&nbsp;
    {record && `${record.name}`}
</span>);

export const OrderformDelete = (props) => <Delete {...props} title={<OrderformDeleteTitle />} />;
