import 'babel-polyfill';
import React, { Component } from 'react';
import { Admin, Resource } from 'admin-on-rest';

import './App.css';

import authClient from './authClient';
//import sagas from './sagas';
import themeReducer from './themeReducer';
import Login from './Login';
import Layout from './Layout';
import Menu from './Menu';
import { Dashboard } from './dashboard';
import customRoutes from './routes';
import translations from './i18n';

import { EmployeeList, EmployeeCreate, EmployeeEdit, EmployeeDelete, EmployeeIcon } from './employees';
import { CustomerList, CustomerCreate, CustomerEdit, CustomerDelete, CustomerIcon } from './customers';
import { WareList, WareCreate, WareEdit, WareDelete, WareIcon } from './ware';
import { ProviderList, ProviderCreate, ProviderEdit, ProviderDelete, ProviderIcon } from './provider';
import { OrderformList, OrderformCreate, OrderformEdit, OrderformDelete, OrderformIcon } from './orderform';
import restClient from './restClient';
//import fakeRestServer from './restServer';

class App extends Component {
    componentWillMount() {
        //this.restoreFetch = fakeRestServer();
    }

    componentWillUnmount() {
        this.restoreFetch();
    }

    render() {
        return (
            <Admin
                title="Quản lý khách hàng"
                restClient={restClient}
                customReducers={{ theme: themeReducer }}
                //customSagas={sagas}
                customRoutes={customRoutes}
                authClient={authClient}
                dashboard={Dashboard}
                loginPage={Login}
                appLayout={Layout}
                menu={Menu}
                messages={translations}
            >
            <Resource name="employees" list={EmployeeList} create={EmployeeCreate} edit={EmployeeEdit} remove={EmployeeDelete} icon={EmployeeIcon} />
            <Resource name="customers" list={CustomerList} create={CustomerCreate} edit={CustomerEdit} remove={CustomerDelete} icon={CustomerIcon} />
            <Resource name="provider" list={ProviderList} create={ProviderCreate} edit={ProviderEdit} remove={ProviderDelete} icon={ProviderIcon} />
            <Resource name="ware" list={WareList} create={WareCreate} edit={WareEdit} remove={WareDelete} icon={WareIcon} />
            <Resource name="orderform" list={OrderformList} create={OrderformCreate} edit={OrderformEdit} remove={OrderformDelete} icon={OrderformIcon} />

            </Admin>
        );
    }
}

export default App;
