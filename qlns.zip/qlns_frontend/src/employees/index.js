import React from 'react';
import {
    Create,
    Delete,
    Edit,
    translate,
    Datagrid,
    DateField,
    DateInput,
    TextField,
    Filter,
    FormTab,
    List,
    LongTextInput,
    TabbedForm,
    EmailField,
    NumberField,
    TextInput,
    SelectInput,
    DateTimeFormat,
    ReferenceManyField,
    SingleFieldList,
    ChipField,
} from 'admin-on-rest';
import Icon from 'material-ui/svg-icons/social/person';

import EditButton from '../buttons/EditButton';
import FullNameField from './FullNameField';

export const EmployeeIcon = Icon;

const EmployeeFilter = (props) => (
    <Filter {...props}>
        <TextInput label="Phone" source="phone" alwaysOn />
	<TextInput label="Email" source="email" alwaysOn />
	<TextInput label="Username" source="uname" alwaysOn />
	<TextInput label="Ma ST" source="MST" alwaysOn />
	<TextInput label="Address" source="address" alwaysOn />
	<TextInput label="Name" source="name" alwaysOn />
    </Filter>
);

const colored = WrappedComponent => props => props.record[props.source] > 500 ?
    <span style={{ color: 'red' }}><WrappedComponent {...props} /></span> :
    <WrappedComponent {...props} />;

const ColoredNumberField = colored(NumberField);
ColoredNumberField.defaultProps = NumberField.defaultProps;

export const EmployeeList = (props) => (
    <List {...props} filters={<EmployeeFilter />} sort={{ field: 'last_seen', order: 'DESC' }} perPage={25}>
        <Datagrid bodyOptions={{ stripedRows: true, showRowHover: true }}>
            <TextField source="uname" />
            <TextField source="name" />
            <EmailField source="email" />
            <TextField source="address" />
            <TextField source="phone" />
            <TextField source="MST" />
            <DateField source="regday" type="date" />
	    <TextField source="total" />
	    <ReferenceManyField label="List customers" reference="customers" target="csmname">
                <SingleFieldList>
                    <ChipField source="cusname" />
                </SingleFieldList>
            </ReferenceManyField>
            <EditButton />
        </Datagrid>
    </List>
);

export const EmployeeCreate = (props) => (
    <Create title="Add new employee" {...props}>
        <TabbedForm>
            <FormTab label="Employee">
                <TextInput source="uname" style={{ display: 'inline-block', marginLeft: 32 }} />
                <TextInput source="name" style={{ display: 'inline-block', marginLeft: 32 }} />
                <TextInput source="email" style={{ display: 'inline-block', marginLeft: 32 }} />
                <TextInput source="address" style={{ display: 'inline-block', marginLeft: 32 }} />
                <TextInput source="phone" style={{ display: 'inline-block', marginLeft: 32 }} />
                <TextInput source="level" style={{ display: 'inline-block', marginLeft: 32 }} />
                <TextInput source="pwd" style={{ display: 'inline-block', marginLeft: 32 }} />
                <TextInput source="details" style={{ display: 'inline-block', marginLeft: 32 }} />
                <TextInput source="total" style={{ display: 'inline-block', marginLeft: 32 }} />
	        <TextInput source="MST" style={{ display: 'inline-block', marginLeft: 32 }}/>
           	<DateInput source="regday" type="date" style={{ display: 'inline-block', marginLeft: 32 }}/>
	        <TextInput source="total" style={{ display: 'inline-block', marginLeft: 32 }}/>
                <SelectInput source="type" choices={[
                    { id: 'admin', name: 'Admin' },
                    { id: 'mod', name: 'Mod' },
                    { id: 'member', name: 'Member' },
                ]} style={{ display: 'inline-block', marginLeft: 32 }}/>
            </FormTab>
        </TabbedForm>
    </Create>
);

const EmployeeTitle = ({ record }) => record ? <FullNameField record={record} size={32} /> : null;

export const EmployeeEdit = (props) => (
    <Edit title={<EmployeeTitle />} {...props}>
	<TabbedForm>
 	    <FormTab label="Employee">
                <TextInput source="uname" style={{ display: 'inline-block', marginLeft: 32 }} />
                <TextInput source="name" style={{ display: 'inline-block', marginLeft: 32 }} />
                <TextInput source="email" style={{ display: 'inline-block', marginLeft: 32 }} />
                <TextInput source="address" style={{ display: 'inline-block', marginLeft: 32 }} />
                <TextInput source="phone" style={{ display: 'inline-block', marginLeft: 32 }} />
                <TextInput source="level" style={{ display: 'inline-block', marginLeft: 32 }} />
                <TextInput source="pwd" style={{ display: 'inline-block', marginLeft: 32 }} />
                <TextInput source="details" style={{ display: 'inline-block', marginLeft: 32 }} />
                <TextInput source="total" style={{ display: 'inline-block', marginLeft: 32 }} />
	        <TextInput source="MST" style={{ display: 'inline-block', marginLeft: 32 }}/>
           	<DateInput source="regday" type="date" style={{ display: 'inline-block', marginLeft: 32 }}/>
		<TextInput source="total" style={{ display: 'inline-block', marginLeft: 32 }}/>
                <SelectInput source="type" choices={[
                    { id: 'admin', name: 'Admin' },
                    { id: 'mod', name: 'Mod' },
                    { id: 'member', name: 'Member' },
                ]} style={{ display: 'inline-block', marginLeft: 32 }}/>
             </FormTab>
	</TabbedForm>
    </Edit>
);

const EmployeeDeleteTitle = translate(({ record, translate }) => <span>
    {translate('resources.employees.page.delete')}&nbsp;
    {record && `${record.name}`}
</span>);

export const EmployeeDelete = (props) => <Delete {...props} title={<EmployeeDeleteTitle />} />;	
