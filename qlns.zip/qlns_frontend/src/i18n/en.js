export default {
    pos: {
        search: 'Search',
        configuration: 'Configuration',
        language: 'Language',
        theme: {
            name: 'Theme',
            light: 'Light',
            dark: 'Dark',
        },
        dashboard: {
            order: {
                items: 'by %{user_name}, one item |||| by %{user_name}, %{nb_items} items',
            },
            welcome: {
                title: 'Phần mềm quản lý thông tin khách hàng - (c) by HA ',
                subtitle: 'Phần mềm hỗ trợ quản lý được thực hiện bởi Hoàng Anh. Phần mềm hỗ trợ quản lý được thực hiện bởi Hoàng Anh. Phần mềm hỗ trợ quản lý được thực hiện bởi Hoàng Anh. Phần mềm hỗ trợ quản lý được thực hiện bởi Hoàng Anh. Phần mềm hỗ trợ quản lý được thực hiện bởi Hoàng Anh. Phần mềm hỗ trợ quản lý được thực hiện bởi Hoàng Anh. Phần mềm hỗ trợ quản lý được thực hiện bởi Hoàng Anh Phần mềm hỗ trợ quản lý được thực hiện bởi Hoàng Anh Phần mềm hỗ trợ quản lý được thực hiện bởi Hoàng Anh .Phần mềm hỗ trợ quản lý được thực hiện bởi Hoàng Anh Phần mềm hỗ trợ quản lý được thực hiện bởi Hoàng AnhPhần mềm hỗ trợ quản lý được thực hiện bởi Hoàng Anh .Phần mềm hỗ trợ quản lý được thực hiện bởi Hoàng Anh Phần mềm hỗ trợ quản lý được thực hiện bởi Hoàng Anh Phần mềm hỗ trợ quản lý được thực hiện bởi Hoàng Anh .Phần mềm hỗ trợ quản lý được thực hiện bởi Hoàng Anh. Phần mềm hỗ trợ quản lý được thực hiện bởi Hoàng Anh Phần mềm hỗ trợ quản lý được thực hiện bởi Hoàng Anh vPhần mềm hỗ trợ quản lý được thực hiện bởi Hoàng Anh. Phần mềm hỗ trợ quản lý được thực hiện bởi Hoàng Anh .Phần mềm hỗ trợ quản lý được thực hiện bởi Hoàng Anh.  ',
                aor_button: 'Trang chủ',
                demo_button: 'Source for this demo',
            },
        },
    },
    resources: {
        employees: {
            name: 'Employee |||| Employees',
            fields: {
                name: 'Name',
		uname: 'UserName',
            },
            tabs: {
                identity: 'Identity',
                address: 'Address',
            },
            page: {
                delete: 'Delete employee',
            },
        },
	customers: {
            name: 'Customer |||| Customers',
            fields: {
                name: 'Name',
            },
            tabs: {
                identity: 'Identity',
                address: 'Address',
            },
            page: {
                delete: 'Delete customer',
            },
        },
	ware: {
            name: 'Ware |||| Wares',
            fields: {
                name: 'Name',
            },
            tabs: {
                identity: 'Identity',
                address: 'Address',
            },
            page: {
                delete: 'Delete ware',
            },
        },
	provider: {
            name: 'Provider |||| Providers',
            fields: {
                name: 'Name',	
            },
            tabs: {
                identity: 'Identity',
                address: 'Address',
            },
            page: {
                delete: 'Delete employee',
            },
        },
        orderform: {
            name: 'Orderform |||| Orderforms',
            fields: {
		email: 'Email',
            },
            tabs: {
                identity: 'Identity',
                address: 'Address',
            },
            page: {
                delete: 'Delete employee',
            },
        },
    },
};
