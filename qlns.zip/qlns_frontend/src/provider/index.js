import React from 'react';
import {
    Create,
    Delete,
    Edit,
    translate,
    Datagrid,
    DateField,
    DateInput,
    TextField,
    Filter,
    FormTab,
    List,
    LongTextInput,
    TabbedForm,
    EmailField,
    NumberField,
    TextInput,
    SelectInput,
} from 'admin-on-rest';
import Icon from 'material-ui/svg-icons/social/person';

import EditButton from '../buttons/EditButton';
import FullNameField from './FullNameField';

export const ProviderIcon = Icon;

const ProviderFilter = (props) => (
    <Filter {...props}>
        <TextInput label="ma" source="ma" alwaysOn />
	<TextInput label="phone" source="phone" alwaysOn />
	<TextInput label="address" source="address" alwaysOn />
    </Filter>
);

const colored = WrappedComponent => props => props.record[props.source] > 500 ?
    <span style={{ color: 'red' }}><WrappedComponent {...props} /></span> :
    <WrappedComponent {...props} />;

const ColoredNumberField = colored(NumberField);
ColoredNumberField.defaultProps = NumberField.defaultProps;

export const ProviderList = (props) => (
    <List {...props} filters={<ProviderFilter />} sort={{ field: 'last_seen', order: 'DESC' }} perPage={25}>
        <Datagrid bodyOptions={{ stripedRows: true, showRowHover: true }}>
	    <TextField source="ma" /> 
	    <TextField source="name" />
            <TextField source="phone" />
            <TextField source="address" />
            <TextField source="details" />
            <EditButton />
        </Datagrid>
    </List>
);

export const ProviderCreate = (props) => (
    <Create title="Add new provider" {...props}>
        <TabbedForm>
            <FormTab label="Provider">
		<TextInput source="ma" style={{ display: 'inline-block', marginLeft: 32 }}/>
            	<TextInput source="name" style={{ display: 'inline-block', marginLeft: 32 }}/>
            	<TextInput source="phone" style={{ display: 'inline-block', marginLeft: 32 }}/>
            	<TextInput source="address" style={{ display: 'inline-block', marginLeft: 32 }}/>
            	<TextInput source="details" style={{ display: 'inline-block', marginLeft: 32 }}/>
            </FormTab>
        </TabbedForm>
    </Create>
);

const ProviderTitle = ({ record }) => record ? <FullNameField record={record} size={32} /> : null;

export const ProviderEdit = (props) => (
    <Edit title={<ProviderTitle />} {...props}>
        <TabbedForm>
            <FormTab label="Provider">
		<TextInput source="ma" style={{ display: 'inline-block', marginLeft: 32 }}/>
            	<TextInput source="name" style={{ display: 'inline-block', marginLeft: 32 }}/>
            	<TextInput source="phone" style={{ display: 'inline-block', marginLeft: 32 }}/>
            	<TextInput source="address" style={{ display: 'inline-block', marginLeft: 32 }}/>
            	<TextInput source="details" style={{ display: 'inline-block', marginLeft: 32 }}/>
            </FormTab>
        </TabbedForm>
    </Edit>
);

const ProviderDeleteTitle = translate(({ record, translate }) => <span>
    {translate('Delete')}&nbsp;
    {record && `${record.name}`}
</span>);

export const ProviderDelete = (props) => <Delete {...props} title={<ProviderDeleteTitle />} />;
