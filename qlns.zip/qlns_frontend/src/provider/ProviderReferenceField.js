import React from 'react';
import { ReferenceField } from 'admin-on-rest';

import FullNameField from './FullNameField';

const ProviderReferenceField = (props) => (
    <ReferenceField source="id" reference="Provider" {...props}>
        <FullNameField />
    </ReferenceField>
);
ProviderReferenceField.defaultProps = {
    source: 'id',
    addLabel: true,
};

export default ProviderReferenceField;
