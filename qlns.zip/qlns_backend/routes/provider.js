var ObjectID = require("bson-objectid");

module.exports = function(db) {
    var module = {};

    module.findById = function(req, res) {
        var id = req.params.id;
        console.log('Retrieving user: ' + id);
        db.collection('provider', function(err, collection) {
            collection.findOne({'_id':ObjectID(id)}, function(err, item) {
                res.header({
                    'ETag': null,
                    'Access-Control-Expose-Headers': 'X-Total-Count',
                    'X-Total-Count': 1
                });
                item.id = item._id;
                console.log(item);
                res.send(item);
            })
        });
    };

    module.findAll = function(req, res) {
	console.log(req.query)
delete req.query['_end'];
delete req.query['_order'];
delete req.query['_sort'];
delete req.query['_start'];
        db.collection('provider', function(err, collection) {
            collection.find(req.query).toArray(function(err, items) {
                res.header({
                    /*'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': '*',
                    'Access-Control-Allow-Methods': 'GET,HEAD,PUT,PATCH,POST,DELETE',
                    */'Access-Control-Expose-Headers': 'X-Total-Count',
                    'X-Total-Count': items.length
                });
                for (i = 0; i < items.length; i++) items[i].id = items[i]._id;
                res.send(items);
            });
        });
    };

    module.add = function(req, res) {
        var provider = req.body;
        console.log('Adding user: ' + JSON.stringify(provider));
        db.collection('provider', function(err, collection) {
            collection.insert(provider, {safe:true}, function(err, result) {
                if (err) {
                    res.send({'error':'An error has occurred'});
                } else {
                    result.ops[0].id = result.ops[0]._id;
                    console.log('Success: ' + JSON.stringify(result));
                    console.log(result.ops);
                    res.send(result.ops[0]);
                }
            });
        });
    }

    module.update = function(req, res) {
        var id = req.params.id;
        var provider = req.body;
        delete provider['id'];
        delete provider['_id'];
        console.log('Updating provider: ' + id);
        console.log(JSON.stringify(provider));
        db.collection('provider', function(err, collection) {
            collection.update({'_id':ObjectID(id)}, provider, {safe:true}, function(err, result) {
                if (err) {
                    console.log('Error updating provider: ' + err);
                    res.send({'error':'An error has occurred'});
                } else {
                    console.log('' + result + ' document(s) updated');
                    provider.id = provider._id;
                    res.send(provider);
                }
            });
        });
    }

    module.delete = function(req, res) {
        var id = req.params.id;
        console.log('Deleting provider: ' + id);
        db.collection('provider', function(err, collection) {
            collection.remove({'_id':ObjectID(id)}, {safe:true}, function(err, result) {
                if (err) {
                    res.send({'error':'An error has occurred - ' + err});
                } else {
                    console.log('' + result + ' document(s) deleted');
                    res.send(req.body);
                }
            });
        });
    }

    return module;
}
